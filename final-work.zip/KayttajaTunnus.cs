﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace final_work
{
    // käyttäjä tunnuksen tallentamiseen käytettävä tietue
    public struct KayttajaTunnus
    {
        public string Kayttaja { get; set; }
    }
}
