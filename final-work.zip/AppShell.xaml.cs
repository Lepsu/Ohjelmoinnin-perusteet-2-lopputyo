﻿namespace final_work;

public partial class AppShell : Shell
{
	public AppShell()
	{
		InitializeComponent();
	}
}
